<?php

class Todays_Deals_Adminhtml_TodaysdealController extends Mage_Adminhtml_Controller_Action
{

		protected function _initAction()
		{
				$this->loadLayout()->_setActiveMenu("deals/todaysdeal")->_addBreadcrumb(Mage::helper("adminhtml")->__("Todaysdeal  Manager"),Mage::helper("adminhtml")->__("Todaysdeal Manager"));
				return $this;
		}
		public function indexAction() 
		{
			    $this->_title($this->__("Deals"));
			    $this->_title($this->__("Manager Todaysdeal"));

				$this->_initAction();
				$this->renderLayout();
		}
		public function editAction()
		{			    
			    $this->_title($this->__("Deals"));
				$this->_title($this->__("Todaysdeal"));
			    $this->_title($this->__("Edit Item"));
				
				$id = $this->getRequest()->getParam("id");
				$model = Mage::getModel("deals/todaysdeal")->load($id);
				if ($model->getId()) {
					Mage::register("todaysdeal_data", $model);
					$this->loadLayout();
					$this->_setActiveMenu("deals/todaysdeal");
					$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Todaysdeal Manager"), Mage::helper("adminhtml")->__("Todaysdeal Manager"));
					$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Todaysdeal Description"), Mage::helper("adminhtml")->__("Todaysdeal Description"));
					$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);
					$this->_addContent($this->getLayout()->createBlock("deals/adminhtml_todaysdeal_edit"))->_addLeft($this->getLayout()->createBlock("deals/adminhtml_todaysdeal_edit_tabs"));
					$this->renderLayout();
				} 
				else {
					Mage::getSingleton("adminhtml/session")->addError(Mage::helper("deals")->__("Item does not exist."));
					$this->_redirect("*/*/");
				}
		}

		public function newAction()
		{

		$this->_title($this->__("Deals"));
		$this->_title($this->__("Todaysdeal"));
		$this->_title($this->__("New Item"));

        $id   = $this->getRequest()->getParam("id");
		$model  = Mage::getModel("deals/todaysdeal")->load($id);

		$data = Mage::getSingleton("adminhtml/session")->getFormData(true);
		if (!empty($data)) {
			$model->setData($data);
		}

		Mage::register("todaysdeal_data", $model);

		$this->loadLayout();
		$this->_setActiveMenu("deals/todaysdeal");

		$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);

		$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Todaysdeal Manager"), Mage::helper("adminhtml")->__("Todaysdeal Manager"));
		$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Todaysdeal Description"), Mage::helper("adminhtml")->__("Todaysdeal Description"));


		$this->_addContent($this->getLayout()->createBlock("deals/adminhtml_todaysdeal_edit"))->_addLeft($this->getLayout()->createBlock("deals/adminhtml_todaysdeal_edit_tabs"));

		$this->renderLayout();

		}
		public function saveAction()
		{

			$post_data=$this->getRequest()->getPost();
			/*echo "<pre>"; print_r($post_data); exit;*/
			if(!empty($_FILES['file']['name']))
			{	
				$this->importFileAction();
			}
			else{

				if ($post_data) {

					try {

						$model = Mage::getModel("deals/todaysdeal")
						->addData($post_data)
						->setId($this->getRequest()->getParam("id"))
						->save();

						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Todaysdeal was successfully saved"));
						Mage::getSingleton("adminhtml/session")->setTodaysdealData(false);

						if ($this->getRequest()->getParam("back")) {
							$this->_redirect("*/*/edit", array("id" => $model->getId()));
							return;
						}
						$this->_redirect("*/*/");
						return;
					} 
					catch (Exception $e) {
						Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
						Mage::getSingleton("adminhtml/session")->setTodaysdealData($this->getRequest()->getPost());
						$this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
					return;
					}

				}
			}
			$this->_redirect("*/*/");
		}



		public function deleteAction()
		{
				if( $this->getRequest()->getParam("id") > 0 ) {
					try {
						$model = Mage::getModel("deals/todaysdeal");
						$model->setId($this->getRequest()->getParam("id"))->delete();
						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item was successfully deleted"));
						$this->_redirect("*/*/");
					} 
					catch (Exception $e) {
						Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
						$this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
					}
				}
				$this->_redirect("*/*/");
		}

		
		public function massRemoveAction()
		{
			try {
				$ids = $this->getRequest()->getPost('td_ids', array());
				foreach ($ids as $id) {
                      $model = Mage::getModel("deals/todaysdeal");
					  $model->setId($id)->delete();
				}
				Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item(s) was successfully removed"));
			}
			catch (Exception $e) {
				Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
			}
			$this->_redirect('*/*/');
		}
			
		/**
		 * Export order grid to CSV format
		 */
		public function exportCsvAction()
		{
			$fileName   = 'todaysdeal.csv';
			$grid       = $this->getLayout()->createBlock('deals/adminhtml_todaysdeal_grid');
			$this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
		} 
		/**
		 *  Export order grid to Excel XML format
		 */
		public function exportExcelAction()
		{
			$fileName   = 'todaysdeal.xml';
			$grid       = $this->getLayout()->createBlock('deals/adminhtml_todaysdeal_grid');
			$this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
		}

		public function importAction()
		{	
		
			$this->loadLayout();
			$this->_setActiveMenu("deals/todaysdeal");

			$this->getLayout()->getBlock("head")->setCanLoadExtJs(true);

			$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Todaysdeal Manager"), Mage::helper("adminhtml")->__("Todaysdeal Manager"));
			$this->_addBreadcrumb(Mage::helper("adminhtml")->__("Todaysdeal Description"), Mage::helper("adminhtml")->__("Todaysdeal Description"));


			$this->_addContent($this->getLayout()->createBlock("deals/adminhtml_todaysdeal_import"))->_addLeft($this->getLayout()->createBlock("deals/adminhtml_todaysdeal_import_tabs"));

			$this->renderLayout();
		}


		/*Import Coupons data custom*/
		public function importFileAction()
		{
			
			try 
			{
				/*File Upload code*/
				$path = Mage::getBaseDir().DS.'var\importexport\importcoupons'.DS;
		        $fname = $_FILES['file']['name'];

		        $uploader = new Varien_File_Uploader('file');		   
		        $uploader->setAllowedExtensions(array('csv'));
		        $uploader->setAllowCreateFolders(true);
		        $uploader->setAllowRenameFiles(false);
		        $uploader->setFilesDispersion(false);		        
		        $uploader->save($path,$fname);

		        /*Get File Content*/
		        $myfileuploadnew = $uploader->getUploadedFileName();		        
				$csv=new Varien_File_Csv();
				$file=$path.$myfileuploadnew;
				$Coupons_csv_data=$csv->getData($file);

				/*Remove Headers From File Content*/
				$count_csvdata = 0;
				foreach($Coupons_csv_data as $value)
				{
					if($count_csvdata > 0)
					{
						$Coupons_csv[$count_csvdata-1] = $value;
					}
					$count_csvdata++;
				}

				$not_saved_ids = "";
				$saved_ids = "";
				$updated_ids = "";
				$not_updated_ids = "";

				foreach($Coupons_csv as $Coupon)
				{
				
					$csv_data['title'] = $Coupon[1];
					$csv_data['content'] = $Coupon[2];
					$csv_data['from_date'] = $Coupon[3];
					$csv_data['to_date'] = $Coupon[4];

					$model_id_exist = Mage::getModel('deals/todaysdeal')->load($Coupon[0])->getData();

					/*Update Record if id alredy exist*/
					if(count($model_id_exist))
					{
						try { 
						    $update_res = Mage::getModel("deals/todaysdeal")
									->addData($csv_data)
									->setId($Coupon[0])
									->save();

						    if($updated_ids == "")
							{
								$updated_ids = $Coupon[0];
							}
							else
							{
								$updated_ids .= ','.$Coupon[0];
							}
						} 
						catch (Exception $e)
						{
						    if($not_updated_ids == "")
							{
								$not_updated_ids = $Coupon[0];
							}
							else
							{
								$not_updated_ids .= ','.$Coupon[0];
							}
						}
					}
					/*Insert new Record*/
					else
					{
						$model = Mage::getModel("deals/todaysdeal")->setData($csv_data);
						try 
						{
						    $insertId = $model->save()->getId();

							if($saved_ids == "")
							{
								$saved_ids = $insertId;
							}
							else
							{
								$saved_ids .= ','.$insertId;
							}
						} 
						catch (Exception $e) 
						{
							$not_saved_ids_arr[$count]['id'] = $Coupon[0]; 
							$not_saved_ids_arr[$count]['error'] = $e->getMessage(); 
							$count++;

							if($not_saved_ids == "")
							{
								$not_saved_ids = $Coupon[0];
							}
							else
							{
								$not_saved_ids .= ','.$Coupon[0];
							}
						}
					}							
				    
				}

				/*Print Report of success or errored ids in session message*/
				if($not_saved_ids == "" && $not_updated_ids == "")
				{
					Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Coupons Are Imported succesfully"));
					if($saved_ids != "")
					{
						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("New Saved Coupons Ids Are :".$saved_ids));
					}
					if($updated_ids != "")
					{
						Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Existing Updated Coupons Ids Are :".$updated_ids));
					}
				}
				else
				{
					if($not_saved_ids != "")
					{
						Mage::getSingleton("adminhtml/session")->addError(Mage::helper("adminhtml")->__("Not Inserted Coupons Ids Are :".$not_save_ids));
					}
					if($not_updated_ids != "")
					{
						Mage::getSingleton("adminhtml/session")->addError(Mage::helper("adminhtml")->__("Not Updated Coupons Ids Are :".$not_updated_ids));
					}
				}
			    

			    $this->_redirect("*/*/");
			    
			}
			catch(Exception $e) {

				Mage::getSingleton("adminhtml/session")->addError($e->getMessage());

				$this->_redirect("*/*/");
				
				return;
			  }		
				 
		}

		public function exportAllCouponsAction()
		{
			$fileName   = 'todaysdeal.csv';
			$grid       = $this->getLayout()->createBlock('deals/adminhtml_todaysdeal_gridnew');
			$this->_prepareDownloadResponse($fileName, $grid->getCsvFile());

			Mage::getSingleton('core/session')->addSuccess('All Coupons successfully Exported !'); 

		}
	}

