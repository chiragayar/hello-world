<?php
class Todays_Deals_Model_Mysql4_Todaysdeal extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("deals/todaysdeal", "td_id");
    }
}