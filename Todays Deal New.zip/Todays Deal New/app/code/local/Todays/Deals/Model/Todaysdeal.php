<?php

class Todays_Deals_Model_Todaysdeal extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("deals/todaysdeal");

    }

}
	 