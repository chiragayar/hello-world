<?php
class Todays_Deals_Block_Adminhtml_Todaysdeal_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("deals_form", array("legend"=>Mage::helper("deals")->__("Item information")));

				
						$fieldset->addField("title", "text", array(
						"label" => Mage::helper("deals")->__("Title"),					
						"class" => "required-entry",
						"required" => true,
						"name" => "title",
						));
					
						$fieldset->addField("content", "textarea", array(
						"label" => Mage::helper("deals")->__("Content"),
						"name" => "content",
						));
					
						$dateFormatIso = Mage::app()->getLocale()->getDateTimeFormat(
							Mage_Core_Model_Locale::FORMAT_TYPE_SHORT
						);

						$fieldset->addField('from_date', 'date', array(
						'label'        => Mage::helper('deals')->__('Date from'),
						'name'         => 'from_date',
						'time' => true,
						'image'        => $this->getSkinUrl('images/grid-cal.gif'),
						'format'       => $dateFormatIso
						));
						$dateFormatIso = Mage::app()->getLocale()->getDateTimeFormat(
							Mage_Core_Model_Locale::FORMAT_TYPE_SHORT
						);

						$fieldset->addField('to_date', 'date', array(
						'label'        => Mage::helper('deals')->__('Date to'),
						'name'         => 'to_date',
						'time' => true,
						'image'        => $this->getSkinUrl('images/grid-cal.gif'),
						'format'       => $dateFormatIso
						));

				if (Mage::getSingleton("adminhtml/session")->getTodaysdealData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getTodaysdealData());
					Mage::getSingleton("adminhtml/session")->setTodaysdealData(null);
				} 
				elseif(Mage::registry("todaysdeal_data")) {
				    $form->setValues(Mage::registry("todaysdeal_data")->getData());
				}
				return parent::_prepareForm();
		}
}
