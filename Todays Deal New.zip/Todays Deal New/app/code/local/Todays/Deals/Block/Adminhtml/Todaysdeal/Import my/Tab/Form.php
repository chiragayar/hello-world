<?php
class Todays_Deals_Block_Adminhtml_Todaysdeal_Import_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		
}
