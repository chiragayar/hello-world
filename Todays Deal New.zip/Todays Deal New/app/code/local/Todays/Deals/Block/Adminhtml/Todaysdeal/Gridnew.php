<?php

class Todays_Deals_Block_Adminhtml_Todaysdeal_Gridnew extends Mage_Adminhtml_Block_Widget_Grid
{

		public function __construct()
		{
				parent::__construct();
				$this->setId("todaysdealGrid");
				$this->setDefaultSort("td_id");
				$this->setDefaultDir("DESC");
				$this->setSaveParametersInSession(true);
		}

		protected function _prepareCollection()
		{
				$collection = Mage::getModel("deals/todaysdeal")->getCollection();
				$this->setCollection($collection);
				return parent::_prepareCollection();
		}
		protected function _prepareColumns()
		{
				$this->addColumn("td_id", array(
				"header" => Mage::helper("deals")->__("ID"),
				"align" =>"right",
				"width" => "50px",
			    "type" => "number",
				"index" => "td_id",
				));
                
				$this->addColumn("title", array(
				"header" => Mage::helper("deals")->__("Title"),
				"index" => "title",
				));

				$this->addColumn("content", array(
				"header" => Mage::helper("deals")->__("Content"),
				"index" => "content",
				));

					$this->addColumn('from_date', array(
						'header'    => Mage::helper('deals')->__('Date from'),
						'index'     => 'from_date',
						'type'      => 'date',
						'format'   => Mage::app()->getLocale()->getDateTimeFormat(Mage_Core_Model_Locale::FORMAT_TYPE_SHORT)
					));

					$this->addColumn('to_date', array(
						'header'    => Mage::helper('deals')->__('Date to'),
						'index'     => 'to_date',
						'type'      => 'date',
						'format'   => Mage::app()->getLocale()->getDateTimeFormat(Mage_Core_Model_Locale::FORMAT_TYPE_SHORT)
					));

			$this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV')); 
			$this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

				return parent::_prepareColumns();
		}

		public function getRowUrl($row)
		{
			   return $this->getUrl("*/*/edit", array("id" => $row->getId()));
		}


		
		protected function _prepareMassaction()
		{
			$this->setMassactionIdField('td_id');
			$this->getMassactionBlock()->setFormFieldName('td_ids');
			$this->getMassactionBlock()->setUseSelectAll(true);
			$this->getMassactionBlock()->addItem('remove_todaysdeal', array(
					 'label'=> Mage::helper('deals')->__('Remove Todaysdeal'),
					 'url'  => $this->getUrl('*/adminhtml_todaysdeal/massRemove'),
					 'confirm' => Mage::helper('deals')->__('Are you sure?')
				));
			return $this;
		}
			

}