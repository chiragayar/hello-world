<?php
class Todays_Deals_Block_Adminhtml_Todaysdeal_Import_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form(array(
				"id" => "import_form",
				"action" => $this->getUrl("*/*/importFile"),
				"method" => "post",
				"enctype" =>"multipart/form-data",
				)
				);
				
				$form->setUseContainer(true);
				$this->setForm($form);

				$fieldset = $form->addFieldset("deals_form", array("legend"=>Mage::helper("deals")->__("Import Coupons")));

				
						$fieldset->addField('cpncsvfile', 'file', array(
			            'label'     => Mage::helper('deals')->__('CSV'),
			            'class'     => 'disable',
			            'required'  => true,
			            'name'      => 'file',
			            ));
					

				if (Mage::getSingleton("adminhtml/session")->getTodaysdealData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getTodaysdealData());
					Mage::getSingleton("adminhtml/session")->setTodaysdealData(null);
				} 
				elseif(Mage::registry("todaysdeal_data")) {
				    $form->setValues(Mage::registry("todaysdeal_data")->getData());
				}

				return parent::_prepareForm();
		}
}
