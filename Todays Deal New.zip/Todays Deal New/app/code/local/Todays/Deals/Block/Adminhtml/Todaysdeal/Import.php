<?php
	
class Todays_Deals_Block_Adminhtml_Todaysdeal_Import extends Mage_Adminhtml_Block_Widget_Form_Container
{
		public function __construct()
		{

				parent::__construct();
				$this->_objectId = "td_id";
				$this->_blockGroup = "deals";
				$this->_controller = "adminhtml_todaysdeal";
				$this->_removeButton("save", "label", Mage::helper("deals")->__("Save Item"));
				$this->_removeButton("reset", "label", Mage::helper("deals")->__("Save Item"));
				$this->_addButton('import', array(
					'type'     => 'submit',
					'onclick'     => 'editForm.submit();',
		            'label'     => Mage::helper('deals')->__('Import File'),
		            'class'     => 'save'
		        ));

		}

		public function getHeaderText()
		{
			return Mage::helper("deals")->__("Import Coupons");
		}
}