<?php
	
class Todays_Deals_Block_Adminhtml_Todaysdeal_Import extends Mage_Adminhtml_Block_Widget_Form_Container
{
		public function __construct()
		{
				$this->_addButton('import', array(
					'type'     => 'submit',
		            'label'     => Mage::helper('deals')->__('Import File'),
		            'onclick'   => 'setLocation(\'' . $this->getUrl('*/*/importFile') .'\')'
		        ));/*
		        $this->_removeButton('save', array(
		        	'title'     => Mage::helper('deals')->__('Save'),
		        	));*/
				parent::__construct();
				$this->_objectId = "td_id";
				$this->_blockGroup = "deals";
				$this->_controller = "adminhtml_todaysdeal";
		}

		public function getHeaderText()
		{
			return Mage::helper("deals")->__("Import Coupon");
		}
}