<?php


class Todays_Deals_Block_Adminhtml_Todaysdeal extends Mage_Adminhtml_Block_Widget_Grid_Container{

	public function __construct()
	{

	$this->_controller = "adminhtml_todaysdeal";
	$this->_blockGroup = "deals";
	$this->_headerText = Mage::helper("deals")->__("Todaysdeal Manager");
	$this->_addButtonLabel = Mage::helper("deals")->__("Add New Item");

	$this->_addButton('import', array(			
            'label'     => Mage::helper('deals')->__('Import CSV'),
            'onclick'   => 'setLocation(\'' . $this->getUrl('*/*/import') .'\')'
        ));
        $this->_addButton('export', array(
            'label'     => Mage::helper('deals')->__('Export CSV'),
            'onclick'   => 'setLocation(\'' . $this->getUrl('*/*/exportAllCoupons') .'\')'
        ));

	parent::__construct();
	
	}

}