<?php
$installer = $this;
$installer->startSetup();
$sql=<<<SQLTEXT
CREATE TABLE IF NOT EXISTS `todays_deal` ( 
	`td_id` INT NOT NULL AUTO_INCREMENT,
	`title` VARCHAR(50) NOT NULL,
	`content` LONGTEXT NOT NULL,
	`from_date` DATETIME NOT NULL,
	`to_date` DATETIME NOT NULL,
	PRIMARY KEY (`td_id`)
	) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SQLTEXT;

$installer->run($sql);
//demo 
Mage::getModel('core/url_rewrite')->setId(null);
//demo 
$installer->endSetup();
	 